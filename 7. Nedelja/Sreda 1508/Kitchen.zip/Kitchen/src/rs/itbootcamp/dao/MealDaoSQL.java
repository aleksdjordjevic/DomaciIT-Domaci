package rs.itbootcamp.dao;

import rs.itbootcamp.database.DatabaseConnection;
import rs.itbootcamp.model.FoodModel;
import rs.itbootcamp.model.MealModel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MealDaoSQL implements MealDao {

    private static final Connection conn = DatabaseConnection.getConnection();

    @Override
    public void insert(MealModel mm) {
        try {
            PreparedStatement st = conn.prepareStatement("INSERT INTO MEAL" + "VALUES (?,?,?,?)");
            st.setInt(1, mm.getMealId());
            st.setString(2, mm.getMealName());
            st.setString(3, mm.getMealDesc());
            st.setString(2, mm.getMealDifficulty());
            st.executeUpdate();
            st.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void delete(int mealId) {
        try {
            PreparedStatement st = conn.prepareStatement("REMOVE FROM MEAL WHERE VALES (?)");
            st.setInt(1, mealId);
            st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(MealModel mm) {
        try {
            PreparedStatement st = conn.prepareStatement("UPDATE meal " +
                    "SET meal_id = ? , " +
                    "meal_name = ?, " +
                    "meal_desc = ? " +
                    "meal_difficulty = ? " +
                    "WHERE meal_id = ?");
            st.setInt(1, mm.getMealId());
            st.setString(2, mm.getMealName());
            st.setString(3, mm.getMealDifficulty());
            st.setString(4, mm.getMealDifficulty());
            st.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public MealModel getMeal(int id) {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM MEAL WHERE meal_id = " + id);
            rs.next() ;
                MealModel oneMeal = new MealModel(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4));
                return oneMeal;

        } catch (SQLException e) {
            e.printStackTrace();
        } return null;
    }

    @Override
    public List<MealModel> getAllMeals() {
        List<MealModel> allMeals = new ArrayList<>();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM MEAL");
            while (rs.next()){
                MealModel newMeal = new MealModel(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                allMeals.add(newMeal);
            }
        }catch (SQLException e){
                e.printStackTrace();
            }
        return allMeals;
        }


    @Override
    public List<String> getFoodMealNames(int meal_id) {
        try {
            Statement st= conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT food_name FROM FOOD WHERE food_id ="  +meal_id);

            while (rs.next()){
                (
                        rs.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mealNames;
    }

    @Override
    public List<FoodModel> getFoodMeal(int meal_id) {
        return null;
    }
}
